#include "RandomNumberGenerator.h"

RandomNumberGenerator::RandomNumberGenerator() {
}

RandomNumberGenerator::~RandomNumberGenerator() {
}

